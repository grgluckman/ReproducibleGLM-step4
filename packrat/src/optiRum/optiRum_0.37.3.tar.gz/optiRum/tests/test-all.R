library("testthat")
test_check("optiRum")
